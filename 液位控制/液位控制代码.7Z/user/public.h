#ifndef __PUBLIC_H__
#define __PUBLIC_H__
typedef unsigned char u8;
typedef unsigned int u16;

#endif